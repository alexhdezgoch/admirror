import { NextRequest, NextResponse } from 'next/server';
import { GoogleGenerativeAI } from '@google/generative-ai';
import {
  HookAnalysisRequest,
  HookLibraryAnalysis,
  AIHookAnalysis,
  HookPattern,
  HookRecommendation,
  HookLibrarySummary,
  EnhancedHookData,
  AdvancedHookType
} from '@/types/analysis';
import { createClient } from '@/lib/supabase/server';

const genAI = new GoogleGenerativeAI(process.env.GEMINI_API_KEY || '');

const HOOK_ANALYSIS_PROMPT = `You are an expert advertising copywriter and conversion specialist. Analyze the following hooks from Meta/Facebook ads and provide deep psychological insights.

HOOKS TO ANALYZE:
{hookData}

For each hook, analyze:
1. **Emotional Triggers**: What emotions does this hook tap into? (curiosity, fear, aspiration, urgency, etc.)
2. **Persuasion Technique**: What copywriting technique is used? (Pattern Interrupt, Social Proof, Scarcity, Authority, Storytelling, Direct Benefit, etc.)
3. **Psychological Principle**: What psychological principle makes this work? (Loss Aversion, Bandwagon Effect, Reciprocity, Anchoring, etc.)
4. **Why It Works**: 2-3 sentences explaining why this hook is effective at stopping the scroll

Classify each hook into one of these ADVANCED TYPES:
- curiosity_gap: Creates information gap that compels reading ("You won't believe...", "The secret to...")
- transformation: Shows before/after or journey ("I went from X to Y", "How I...")
- contrarian: Challenges conventional wisdom ("Everything you know about X is wrong", "Why X doesn't work")
- number_driven: Uses specific numbers for credibility ("7 ways to...", "83% of people...")
- pain_point: Directly addresses frustration ("Tired of X?", "Struggling with Y?")
- aspirational: Paints desirable future ("Imagine if...", "What if you could...")
- fear_based: Leverages fear of loss or mistake ("Don't make this mistake...", "Warning:")
- authority: Uses expert credibility ("Experts say...", "Doctors recommend...")
- story_opener: Begins a narrative ("Last year, I...", "My client Sarah...")
- direct_benefit: States clear outcome ("Get X in Y days", "Achieve X without Y")
- question: Engages with a question format
- challenge: Issues a challenge or dare ("I bet you can't...", "Try this...")

Score each hook:
- attentionScore (1-10): How well does it stop the scroll?
- clarityScore (1-10): How clear is the message?
- relevanceScore (1-10): How targeted to the audience?
- overallScore (1-10): Combined effectiveness

After analyzing individual hooks, identify:
1. **Patterns**: Common approaches used across multiple hooks
2. **Recommendations**: Generate 3-5 NEW hook suggestions based on the successful patterns and gaps
3. **Summary**: Dominant styles, emotional themes, gaps to exploit

Return a JSON object with this exact structure:
{
  "hookAnalyses": [
    {
      "hookText": "The original hook text",
      "emotionalTriggers": ["emotion1", "emotion2"],
      "persuasionTechnique": "technique name",
      "psychologicalPrinciple": "principle name",
      "whyItWorks": "2-3 sentence explanation",
      "advancedType": "type_from_list_above",
      "confidence": 85,
      "attentionScore": 8,
      "clarityScore": 7,
      "relevanceScore": 9,
      "overallScore": 8
    }
  ],
  "patterns": [
    {
      "name": "Pattern Name",
      "description": "Description of the pattern",
      "frequency": 5,
      "avgScore": 7.5,
      "exampleHooks": ["hook1", "hook2"]
    }
  ],
  "recommendations": [
    {
      "suggestedHook": "New suggested hook text",
      "basedOn": ["original hook 1", "original hook 2"],
      "targetEmotion": "primary emotion",
      "estimatedEffectiveness": 8,
      "reasoning": "Why this hook would work well"
    }
  ],
  "summary": {
    "dominantTypes": ["type1", "type2"],
    "emotionalThemes": ["theme1", "theme2"],
    "gaps": ["Missing approach 1", "Untapped angle 2"],
    "topPerformingStyle": "Description of most effective style"
  }
}

Be specific, actionable, and insightful. Focus on what makes each hook psychologically effective.`;

export async function POST(request: NextRequest) {
  try {
    // Check authentication
    const supabase = createClient();
    const { data: { user } } = await supabase.auth.getUser();

    if (!user) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const body: HookAnalysisRequest = await request.json();

    // Validate API key
    if (!process.env.GEMINI_API_KEY) {
      return NextResponse.json(
        { success: false, error: 'Gemini API key is not configured.' },
        { status: 500 }
      );
    }

    // Validate request
    if (!body.brandId || !body.hooks || body.hooks.length === 0) {
      return NextResponse.json(
        { success: false, error: 'brandId and at least one hook are required' },
        { status: 400 }
      );
    }

    // Check for cached analysis
    const { data: cached } = await supabase
      .from('hook_analyses')
      .select('analysis, analyzed_at')
      .eq('brand_id', body.brandId)
      .single();

    if (cached) {
      // Return cached analysis if it's less than 24 hours old
      const cachedTime = new Date(cached.analyzed_at);
      const now = new Date();
      const hoursSinceCached = (now.getTime() - cachedTime.getTime()) / (1000 * 60 * 60);

      if (hoursSinceCached < 24) {
        return NextResponse.json({
          success: true,
          analysis: cached.analysis as unknown as HookLibraryAnalysis,
          cached: true,
          analyzedAt: cached.analyzed_at
        });
      }
    }

    // Prepare hook data for the prompt (limit to top 15 hooks to stay within token limits)
    const hooksForAnalysis = body.hooks.slice(0, 15).map(hook => ({
      text: hook.text,
      type: hook.type,
      frequency: hook.frequency
    }));

    const prompt = HOOK_ANALYSIS_PROMPT.replace(
      '{hookData}',
      JSON.stringify(hooksForAnalysis, null, 2)
    );

    // Get the model - use gemini-2.0-flash for better rate limits
    const model = genAI.getGenerativeModel({ model: 'gemini-2.0-flash' });

    const result = await model.generateContent(prompt);
    const response = result.response;
    const text = response.text();

    // Parse the JSON response
    let jsonStr = text;
    const jsonMatch = text.match(/```(?:json)?\s*([\s\S]*?)```/);
    if (jsonMatch) {
      jsonStr = jsonMatch[1].trim();
    }

    let analysisData;
    try {
      analysisData = JSON.parse(jsonStr);
    } catch {
      console.error('Failed to parse Gemini response:', text);
      return NextResponse.json(
        { success: false, error: 'Failed to parse hook analysis response' },
        { status: 500 }
      );
    }

    // Map the AI analyses back to the original hooks
    const enhancedHooks: EnhancedHookData[] = body.hooks.map(hook => {
      const aiAnalysis = analysisData.hookAnalyses?.find(
        (a: { hookText: string }) => a.hookText.toLowerCase() === hook.text.toLowerCase()
      );

      if (aiAnalysis) {
        const analysis: AIHookAnalysis = {
          emotionalTriggers: aiAnalysis.emotionalTriggers || [],
          persuasionTechnique: aiAnalysis.persuasionTechnique || 'Unknown',
          psychologicalPrinciple: aiAnalysis.psychologicalPrinciple || 'Unknown',
          whyItWorks: aiAnalysis.whyItWorks || '',
          advancedType: (aiAnalysis.advancedType || 'question') as AdvancedHookType,
          confidence: aiAnalysis.confidence || 50,
          attentionScore: aiAnalysis.attentionScore || 5,
          clarityScore: aiAnalysis.clarityScore || 5,
          relevanceScore: aiAnalysis.relevanceScore || 5,
          overallScore: aiAnalysis.overallScore || 5
        };

        return {
          text: hook.text,
          type: hook.type,
          frequency: hook.frequency,
          adIds: hook.adIds,
          aiAnalysis: analysis
        };
      }

      return {
        text: hook.text,
        type: hook.type,
        frequency: hook.frequency,
        adIds: hook.adIds
      };
    });

    // Process patterns
    const patterns: HookPattern[] = (analysisData.patterns || []).map((p: HookPattern) => ({
      name: p.name || 'Unnamed Pattern',
      description: p.description || '',
      frequency: p.frequency || 0,
      avgScore: p.avgScore || 0,
      exampleHooks: p.exampleHooks || []
    }));

    // Process recommendations
    const recommendations: HookRecommendation[] = (analysisData.recommendations || []).map((r: HookRecommendation) => ({
      suggestedHook: r.suggestedHook || '',
      basedOn: r.basedOn || [],
      targetEmotion: r.targetEmotion || 'curiosity',
      estimatedEffectiveness: r.estimatedEffectiveness || 5,
      reasoning: r.reasoning || ''
    }));

    // Process summary
    const summary: HookLibrarySummary = {
      dominantTypes: analysisData.summary?.dominantTypes || [],
      emotionalThemes: analysisData.summary?.emotionalThemes || [],
      gaps: analysisData.summary?.gaps || [],
      topPerformingStyle: analysisData.summary?.topPerformingStyle || ''
    };

    const analyzedAt = new Date().toISOString();
    const analysis: HookLibraryAnalysis = {
      hooks: enhancedHooks,
      patterns,
      recommendations,
      summary,
      analyzedAt
    };

    // Save analysis to Supabase cache (if user is authenticated)
    if (user) {
      await supabase.from('hook_analyses').upsert({
        brand_id: body.brandId,
        user_id: user.id,
        analysis: JSON.parse(JSON.stringify(analysis)),
        analyzed_at: analyzedAt
      }, { onConflict: 'brand_id' });
    }

    return NextResponse.json({
      success: true,
      analysis,
      cached: false,
      analyzedAt
    });

  } catch (error) {
    console.error('Error in hook analysis route:', error);
    return NextResponse.json(
      {
        success: false,
        error: error instanceof Error ? error.message : 'An unexpected error occurred'
      },
      { status: 500 }
    );
  }
}
